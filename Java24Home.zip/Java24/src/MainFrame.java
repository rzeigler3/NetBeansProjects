import javax.swing.*;

public class MainFrame extends JFrame {
    public MainFrame() {
        super("Main Frame");        // or you cna use setTitle();
        setSize(350, 125);          // or you can use pack();
        setDefaultCloseOperation(JFrame.Exit_ON_CLOSE);
    }
    UI.Manager.setLookAndFeel(
    "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel"
    );
}