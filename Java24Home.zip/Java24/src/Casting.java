public class Casting {
    public static void main(String[] args) {
        double source = 5.55;
        
        int destination = (int) source;
        
        System.out.println("source = " + source + "\n"
        + "destination = " + destination);
    }
}