public class ErrorCorrectionModem extends Modem {
    // program goes here
}