public class Modem {
    //NO MAIN HERE
    int speed;
    
        public void displaySpeed() {
            System.out.println("Speed: " + speed);
        }
}
