public class VirusStuff {
    private int newSeconds = 86;
    public String author = "Sam Snett";
    int maxFileSize = 30000; 
    
    VirusStuff influenza = new VirusStuff();                  // new object
    influenza.newSeconds = 92;
    
    static int virusCount = 0;
    
    public boolean infectFile(String filename) {    // class method
        boolean success = false;
        // file-infecting statements go here
        return success;
    }
    
    if (malaria.infectFile(currentFile)) {          // if malaria.infectedFile() returns true
        System.out.println(currentFile + " has been infected!");
    } else {
        System.out.println("Curses! Foiled again!");
    }
    
    public int getSeconds() {
        return newSeconds;
    }
    
    public void setSeconds(int newValue) {
       if (newValue < 60) {
           newSeconds = newValue;
       }
    }
    
}

